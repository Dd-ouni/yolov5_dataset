



if __name__ == '__main__':
    import argparse
    import sys

    from controller.command import Command
    # from lib.bass import Bass
    #
    # parser = argparse.ArgumentParser()
    # parser.add_argument('-m', '--mode', default='cmd', choices=['cmd'], help='the program run mode, default is gui.')
    # parser.add_argument('files', metavar='file', nargs='*')
    #
    # args = parser.parse_args()
    # controller = Command(args)
    #
    # Bass.init()
    # code = controller.start()
    # Bass.free()
    # sys.exit(code)
