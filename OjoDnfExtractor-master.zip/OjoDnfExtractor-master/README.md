# OjoDnfExtractor

本程序为dnf数据文件提取工具，支持NPK/IMG（ver1-ver6）素材的提取。

本程序根据**GPLV3**协议开源，如在此基础上进行修改，请将你修改的项目开源。

## 下载地址

* [OS X](http://project.stor.hsojo.com/OjoDnfExtractor.app.zip)

* [Windows](http://project.stor.hsojo.com/OjoDnfExtractor.exe)

> 以上两个为上古版本，最新版本请到**releases页**自行下载。

由于开发环境没有安装linux系统，所以，需要的话就要自己动手打包了。

打包所需的库：

* [Bass](http://www.un4seen.com/)

