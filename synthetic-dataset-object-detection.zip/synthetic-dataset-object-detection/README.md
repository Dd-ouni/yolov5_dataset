# How to Create Synthetic Dataset for Computer Vision (Object Detection)  

### Detailed explanation
https://medium.com/@alexppppp/how-to-create-synthetic-dataset-for-computer-vision-object-detection-fd8ab2fa5249
